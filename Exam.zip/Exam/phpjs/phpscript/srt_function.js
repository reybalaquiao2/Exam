app.factory("ngFunctions", function($rootScope, $timeout, $filter, $http) {
	return {
		loadTables: function() {
			var vm = this;
			var error = false;
			
			angular.forEach($rootScope.settings.tables, function(v, k) {
				if(!error) {					
					vm.getHttp("settings", v[0], v[0], [["WHERE", "EmployeeNo", "NOT LIKE", "NULL"]], [], function(response){
						if(response == "error") {
							error = true;
						} else {
							delete $rootScope.settings.selected[v[0]];
							
							$(document).ready(function() {
								$("#" + v[0] + "Table").DataTable().clear().destroy();
								$("#" + v[0] + "SearchInput").val("");
								
								var table = $("#" + v[0] + "Table").DataTable({
									data: $rootScope.settings[v[0]],
									select: "single",
									"scrollY": "50vh",
									"scrollX": true,
									"scrollCollapse": true,
									"lengthChange": false,
									"pageLength": 100,
									columns: v[1]
								});
								
								$("#" + v[0] + "SearchInput").on("keyup", function() {
									table.search($(this).val()).draw();
								});
								
								$("#" + v[0] + "Table tbody").on("click", "tr", function() {
									$(this).addClass('focused-row');
									
									if($(this).attr("class").indexOf("selected") < 0) {
										if(!$("#" + v[0] + "Table tbody tr.focused-row td:first-child").hasClass("dataTables_empty")) {
											$rootScope.settings.selected[v[0]] = $("#" + v[0] + "Table tbody tr.focused-row td:first-child").text();
											$(this).removeClass('focused-row');
										}
									} else {
										delete $rootScope.settings.selected[v[0]];
									}
								});
							});
						}
						vm.spinner("hide", 1000);
					});
				} else {
					vm.showAlert(true, "warning", "ERROR", "Loading of tables failed. Try to refresh the page.");
				}
			});
		},
		toUpper: function(item) {
			if (typeof($rootScope.form[item]) != "undefined" && $rootScope.form[item] != "") {
				$rootScope.form[item] = $rootScope.form[item].toUpperCase();
			}
		},
		validateForm: function() {
			var error = false;
			var message = "";
			
			angular.forEach($rootScope.rules, function(v, k) {
				if(!error) {
					angular.forEach(v, function(inv, ink) {
						switch(k) {
							case "required":
								if(typeof($rootScope.form[inv]) == "undefined" || $rootScope.form[inv] == "") {
									error = true;
									message = "There still have remaining required fields.";
								}
								break;
							case "formatLen":
								if(typeof($rootScope.form[ink]) != "undefined" && $rootScope.form[ink] != "" && $rootScope.form[ink].length != inv[0]) {
									error = true;
									message = "Invalid " + inv[1];
								}
								break;
						}
					});
				}
			});
			
			if(error) {	
				this.showAlert(error, "warning", "ERROR", message);
				return false;
			} else {
				return true;
			}
		},
		validateResponse: function(response) {
			error = false;
			message = "";
			
			if(typeof(response) != "undefined" && typeof(response) == "string") {
				angular.forEach($rootScope.settings.errorKey, function(v, k) {
					if(!error && response.indexOf(v) > 0) {
						switch(v) {
							case "No connection":
									error = true;
									message = "Host connection failed. Please try again.";									
								break;
							case "Fatal error":
									error = true;
									message = "Request failed. Please try again.";								
								break;
							case "Reading File Error":
									error = true;
									message = "Reading file failed. There's something wrong within the uploading file.";
								break;
						}
					}
				});
			}
			if(error){
				this.showAlert(!error, "warning", "ERROR", message);
			}
			
			return !error;
		},
		getHttp: function(obj, key, table, where, order, callback) {
			var vm = this;
			
			$http({
				method: "POST",
				url: "ajax.php",
				type: "application/json",
				params: {
					validate: true,
					action: "get",
					table: table,
					where: JSON.stringify(where),
					order: JSON.stringify(order)
				}
			}).then(function(response) {
				if(vm.validateResponse(response.data)) {
					$rootScope[obj][key] = response.data;
					callback("success");
				} else {
					callback("error");
				}
			});
		},
		postHttp: function(table, obj, callback) {
			var vm = this;
			
			$http({
				method: "POST",
				url: "ajax.php",
				type: "application/json",
				params: {
					validate: true,
					action: "post",
					table: table,
					values: JSON.stringify(obj)
				}
			}).then(function(response) {
				if(vm.validateResponse(response.data)) {
					callback("success");
				} else {
					callback("error");
				}
			});
		},
		updateHttp: function(table, obj, where, callback) {
			var vm = this;
			
			$http({
				method: "POST",
				url: "ajax.php",
				type: "application/json",
				params: {
					validate: true,
					action: "update",
					table: table,
					where: JSON.stringify(where),
					values: JSON.stringify(obj)
				}
			}).then(function(response) {
				if(vm.validateResponse(response.data)) {
					callback("success");
				} else {
					callback("error");
				}
			});
		},
		deleteHttp: function(table, where, callback) {
			var vm = this;
			
			$http({
				method: "POST",
				url: "ajax.php",
				type: "application/json",
				params: {
					validate: true,
					action: "delete",
					table: table,
					where: JSON.stringify(where)
				}
			}).then(function(response) {
				if(vm.validateResponse(response.data)) {
					callback("success");
				} else {
					callback("error");
				}
			});
		},
		download: function(table) {
			var vm = this;
			var sqlHeaders = "";
			var sqlExtFile = "";
			
			angular.forEach($rootScope.settings.exports, function(v, k) {
				sqlHeaders = sqlHeaders + ", " + v.field + " AS " + v.as;
			});

			alasql.promise('SELECT ' + sqlHeaders.substr(2) + ' INTO CSV("' + table + '.csv", {headers:true}) FROM ?', JSON.parse(JSON.stringify([$rootScope.settings[table]]).replace(/\:null/gi, "\:\"\""))).then(function(response) {
				vm.showAlert(false, "thumbs-o-up", "INFO", "Successfully Downloaded.");
			}).catch(function(err){
				vm.showAlert(true, "warning", "ERROR", "There\'s something wrong downloading the data.");
			});
		},
		showModal: function(id) {
			var modalDialog = angular.element("#" + id);
			modalDialog.modal("show");
		},
		
		hideModal: function(id) {
			var modalDialog = angular.element("#" + id);
			modalDialog.modal("hide");
		},
		showAlert: function(autoClose, type, title, message) {		
			$rootScope.settings.modal.type = type;
			$rootScope.settings.modal.title = title;
			$rootScope.settings.modal.message = message;
			
			var vm = this;
			var modalDialog = angular.element("#AlertModal");
			
			if(modalDialog) {
				$timeout(function() {
					vm.spinner("hide", 0);
				}, 500).then(function() {
					modalDialog.modal("show");
				});
				
				if(autoClose) {
					$timeout(function() {
						modalDialog.modal("hide");
					}, 5000);
				}
			}
		},
		spinner: function(action, time) {
			var spinnerDialog = angular.element("#spinner");
			
			if(spinnerDialog) {
				if(time > 0) {
					$timeout(function() {
						spinnerDialog.modal(action);
					}, time);
				} else {
					spinnerDialog.modal(action);
				}
			}
		}
	};
});

app.directive("uppercaseOnly", function() {
	return {
		restrict: "A",
		require: "ngModel",
		link: function(scope, element, attr, ngModelCtrl) {
			element.on("keypress", function(e) {
				var char = e.char || String.fromCharCode(e.charCode);
				if(!/^[A-Z0-9\s]$/i.test(char)) {
					e.preventDefault();
					return false;
				}
			});
			
			function parser(value) {
				if(ngModelCtrl.$isEmpty(value)) {
					return value;
				}
				
				var formatedValue = value.toUpperCase();
				
				if(ngModelCtrl.$viewValue !== formatedValue) {
					ngModelCtrl.$setViewValue(formatedValue);
					ngModelCtrl.$render();
				}
				
				return formatedValue;
			}
			
			function formatter(value) {
				if(ngModelCtrl.$isEmpty(value)) {
					return value;
				}
				return value.toUpperCase();
			}
			
			ngModelCtrl.$formatters.push(formatter);
			ngModelCtrl.$parsers.push(parser);
		}
	};
});

app.directive("numbersOnly", function() {
	return {
		require: "ngModel",
		link: function(scope, element, attr, ngModelCtrl) {
			function fromUser(text) {
				if(text) {
					var transformedInput = text.replace(/[^0-9]/g, "");
				
					if(transformedInput !== text) {
						ngModelCtrl.$setViewValue(transformedInput);
						ngModelCtrl.$render();
					}
					return transformedInput;
				}
				return undefined;
			}
			ngModelCtrl.$parsers.push(fromUser);
		}
	};
});