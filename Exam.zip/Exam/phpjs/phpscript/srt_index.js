var app = angular.module("IndexApp", ["ngResource"])
	.controller("IndexCtrl", function($scope, $rootScope, $resource, $http, ngFunctions) {
		$rootScope.form = {};
		
		$rootScope.rules = {
			required: [
				"EmployeeNo",
				"FirstName",
				"LastName",
				"Department"
			],
			formatLen: {
				EmployeeNo: [8, "Employee No. Must be 8 Numeric Digit."]
			},
		};
		
		$rootScope.settings = {
			enabled: true,
			highlighted: false,
			selected: {},
			tables: [
				["employee", [
						{"data": "EmployeeCode"},
						{"data": "EmployeeNo"},
						{"data": "FirstName"},
						{"data": "LastName"},
						{"data": "Department"}
					]
				]
			],
			exports: headers = [
				{field:"EmployeeCode" , as:"EmployeeCode"},
				{field:"EmployeeNo" , as:"EmployeeNo"},
				{field:"FirstName" , as:"FirstName"},
				{field:"LastName" , as:"LastName"},
				{field:"Department" , as:"Department"}
			],
			modal: {
				type: null,
				title: null,
				message: null
			},
			errorKey: [
				"Fatal error",
				"No connection"
			]
		};
		
		ngFunctions.loadTables();
		
		$scope.openModal = function(id, action) {
			$rootScope.settings.enabled = true;
			
			if(action == "Add") {
				$rootScope.form = {};
				
				$("#AddButton").show();
				$("#EditButton").hide();
			} else if (action != "Delete") {
				if(action == "Edit") {
					$("#AddButton").hide();
					$("#EditButton").show();
				} else {
					$("#AddButton").hide();
					$("#EditButton").hide();
					
					$rootScope.settings.enabled = false;
				}
				
				if(typeof($rootScope.settings.selected.employee) != "undefined") {
					angular.forEach($rootScope.settings.employee, function(v, k) {
						if(v.EmployeeCode == $rootScope.settings.selected.employee) {
							$rootScope.form = v;
						}
					});
				}	
			}
			
			ngFunctions.showModal(id);
		}
		
		$scope.closeModal = function(id) {
			ngFunctions.hideModal(id);
		};
		
		$scope.add = function() {
			if(ngFunctions.validateForm()) {
				ngFunctions.getHttp("settings", "employee", "employee", [["WHERE", "EmployeeNo", "=", $rootScope.form.EmployeeNo]], [], function(response) {
					if(response == "success") {
						if($rootScope.settings.employee.length == 1) {
							ngFunctions.showAlert(false, "warning", "ERROR", "Submit failed, Duplicate Entries.");
						} else if($rootScope.settings.employee.length > 1) {
							ngFunctions.showAlert(true, "warning", "ERROR", "Employee with Employee No. " + $rootScope.form.EmployeeNo + " already exist and have more than one duplicates.");
						} else {
							ngFunctions.postHttp("employee", $rootScope.form, function(response){
								if(response == "success") {
									ngFunctions.loadTables();
									ngFunctions.showAlert(false, "thumbs-o-up", "INFO", "Successfully submitted.");
								}
							});
						}
					}
					
					$scope.closeModal("EmployeeModal");
				});
			}
		};
		
		$scope.edit = function() {
			if(ngFunctions.validateForm()) {			
				ngFunctions.getHttp("settings", "employee", "employee", [["WHERE", "EmployeeNo", "=", $rootScope.form.EmployeeNo], ["AND", "FirstName", "LIKE", $rootScope.form.FirstName], ["AND", "LastName", "LIKE", $rootScope.form.LastName]], [], function(response) {
					if(response == "success") {
						if($rootScope.settings.employee.length == 1) {
							ngFunctions.showAlert(false, "warning", "ERROR", "Submit failed, Duplicate Entries.");
						} else if($rootScope.settings.employee.length > 1) {
							ngFunctions.showAlert(true, "warning", "ERROR", "Employee " + $rootScope.form.EmployeeNo + " already exist and have more than one duplicates.");
						} else {
							var code = $rootScope.form.EmployeeCode;
							delete $rootScope.form.EmployeeCode;
							
							ngFunctions.updateHttp("employee", $rootScope.form, [["WHERE", "EmployeeCode", "=", code]], function(response){
								if(response == "success") {
									delete $rootScope.settings.selected.employee;
									
									ngFunctions.loadTables();
									ngFunctions.showAlert(false, "thumbs-o-up", "INFO", "Successfully updated.");
								}
							});
						}
					}
					
					$scope.closeModal("EmployeeModal");
				});
			}
		};
		
		$scope.Delete = function() {
			ngFunctions.deleteHttp("employee", [["WHERE", "EmployeeCode", "=", $rootScope.settings.selected.employee]], function(response){
				if(response == "success") {
					delete $rootScope.settings.selected.employee;
					
					ngFunctions.loadTables();
					ngFunctions.showAlert(false, "thumbs-o-up", "INFO", "Successfully deleted.");
				}
			});
			
			$scope.closeModal("ConfirmModal");
		};
		
		$scope.download = function() {
			ngFunctions.spinner("show", 0);
			
				$rootScope.settings.employee = {};
				
				ngFunctions.getHttp("settings", "employee", "employee", [["WHERE", "EmployeeNo", "NOT LIKE", "NULL"]], [], function(response) {
					if(response == "success") {
						if($rootScope.settings.employee.length > 0) {
							ngFunctions.download("employee");
						} else {
							ngFunctions.AlertModal(false, "warning", "ERROR", "No data available.");
						}
					}
				});	
		};
		
		$("#employeeTable").on("click", "tr", function() {
			if($(this).attr("class").indexOf("selected") < 0) {
				if(!$("#employeeTable tr.focused-row td:first-child").hasClass("dataTables_empty")) {
					$rootScope.settings.highlighted = true;
				}
			} else {
				$rootScope.settings.highlighted = false;
			}
		});
	});