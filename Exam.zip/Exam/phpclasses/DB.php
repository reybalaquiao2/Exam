<?php
	define("host", "localhost", TRUE);
	define("port", 3307, TRUE);
	define("db", "exam", TRUE);
	define("user", "root", TRUE);
	define("pass", "usbw", TRUE);
	
	Class DB {
		private static $_instance = null;
		private $pdo,
				$sql,
				$query,
				$value,
				$table,
				$error,
				$status,
				$result,
				$count = 0;
				
		private function __construct() {
			try {
				$this->pdo = new PDO("mysql:host=" . host . ":" . port . ";dbname=" . db, user, pass);
			} catch(PDOException $e) {
				die($e->getMessage());
			}
		}
		
		public static function getInstance() {
			if(!isset(self::$_instance)) {
				self::$_instance = new DB();
			}
			return self::$_instance;
		}
		
		public function post($settings = array()) {
			if(count($settings)) {
				$this->value = array();
				$this->table = $settings['table'];
				$fields = "";
				$values = "";
				
				if(count($settings['values']) > 0 and json_decode($settings['values']) == true) {
					$settings['values'] = json_decode($settings['values']);
				}
				
				foreach($settings['values'] as $key => $value) {
					$fields .= ",{$key}";
					$values .= ",?";
					array_push($this->value, $value);
				}
				$fields = substr($fields, 1);
				$values = substr($values, 1);
				
				$this->sql = "INSERT INTO {$settings['table']} ({$fields}) VALUES ({$values})";
				
				if(!$this->query($this->sql, $this->value)->error()) {
					return $this;
				}
			}
			
			return false;
		}
		
		public function update($settings = array()) {
			if(count($settings)) {
				$this->table = $settings['table'];
				$values = array();
				$where = array();
				$sets = "";
				
				if(count($settings['values']) > 0 and json_decode($settings['values']) == true) {
					$settings['values'] = json_decode($settings['values']);
				}
				
				if(array_key_exists('where', $settings) and isset($settings['where'])) {
					$where = $settings['where'];
				}
				
				$this->where($where);
				
				foreach($settings['values'] as $key => $value) {
					$sets .= ",{$key} = ?";
					array_push($values, $value);
				}
				
				foreach($this->value as $value) {
					array_push($values, $value);
				}
				$sets = substr($sets, 1);
				
				$this->value = $values;
				
				$this->sql = "UPDATE {$settings['table']} SET {$sets} {$this->sql}";
				
				if(!$this->query($this->sql, $this->value)->error()) {
					return $this;
				}
			}
			
			return false;
		}
		
		public function delete($settings = array()) {
			$this->table = $settings['table'];
			
			if(array_key_exists('where', $settings) and isset($settings['where'])) {
				$where = $settings['where'];
			}
			
			$this->buildSql("DELETE {$this->table}.*")->where($where);
			
			if(!$this->query($this->sql, $this->value)->error()) {
				return $this;
			}
			
			return false;
		}
	
		public function get($settings = array()) {
			if(count($settings)) {
				$where = array();
				$order = array();
				
				if(array_key_exists('order', $settings) and isset($settings['order'])) {
					$order = $settings['order'];
				}
				if(array_key_exists('where', $settings) and isset($settings['where'])) {
					$where = $settings['where'];
				}
				
				return $this->getAction($settings['table'], $where, $order);
			}
			
			return false;
		}
			
		private function getAction($table, $where, $order) {
			$this->table = $table;
			
			$this->buildSql("SELECT {$this->table}.*")->where($where)->order($order);
			
			if(!$this->query($this->sql, $this->value)->error()) {
				return $this;
			}
			
			return false;
		}
		
		public function query($sql, $params = array()) {
			$this->error = false;
			if($this->query = $this->pdo->prepare($sql)) {
				$x = 1;
				if(count($params)) {
					foreach($params as $param) {
						$this->query->bindValue($x, $param);
						$x++;
					}
				}
				
				if($this->query->execute()){
					$this->result = $this->query->fetchAll(PDO::FETCH_OBJ);
					$this->count = $this->query->rowCount();
					$this->status = "success";
				} else {
					$this->error = true;
				}
			}
			
			return 	$this;
		}
		
		private function buildSql($action) {
			include("phpclasses/References.php");
			
			$this->sql = "{$action}";
			$table = $this->table;
			$join = '';
			
			if(array_key_exists($table, (array) $variables->buildsql->fields)) {
				$x = 'A';
				
				foreach($variables->buildSql->fields->$table as $value) {
					foreach($variables->buildSql->references as $inkey => $invalue) {
						if(in_array($value, (array) $invalue->fields)) {
							
							foreach($invalue->show as $onkey => $onvalue) {
								$this->sql .= ", {$x}.{$onvalue}";
							}
							
							if(isset($invalue->as)) {
								$askey = array_search($value, (array) $invalue->fields);
								$this->sql .= " AS {$invalue->as[$askey]}";
							}
							$join .= " LEFT JOIN ref_{$inkey} AS {$x} on {$x}.{$invalue->on} = {$table}.{$value}";
							$x++;
						}
					}
				}
			}
			
			if(array_key_exists($table, (array) $variables->buildsql->masks)) {
				foreach($variables->buildsql->masks->$table as $value) {
					$this->sql .= ", DATE_FORMAT({$table}.{$value}, '%m/%d/%Y') AS {$value}mask";
				}
			}
			
			if(array_key_exists($table, (array) $variables->buildsql->cast)) {
				foreach($variables->buildsql->cast->$table as $value) {
					$this->sql .= ", DATE_FORMAT({$table}.{$value}, '%h:%i %p') AS {$value}cast";
				}
			}
			
			if(array_key_exists($table, (array) $variables->buildsql->replace)) {
				foreach($variables->buildsql->replace->$table as $value) {
					$this->sql .= ", REPLACE({$table}.{$value[0]}, '{$value[1]}', '{$value[2]}') AS {$value[0]}replace";
				}
			}
			
			$this->sql .= " FROM {$table}{$join}";
			
			return $this;
		}
		
		private function where($data) {
			include("phpclasses/References.php");
			
			$this->value = array();
			
			if(!is_array($data)){
				$tempdata = json_decode($data);
				
				if(json_last_error() === JSON_ERROR_NONE) {
					$data = json_decode($data);
				}
			}
			
			if(count($data)) {
				foreach($data as $key => $value) {
					if(count($value) == 4) {
						$operators = array('=', '!=', '>', '<', '>=', '<=', 'LIKE', 'NOT LIKE');
						
						$contructor = $value[0];
						$field = $value[1];
						$operator = $value[2];
						$search = $value[3];
						
						if(in_array($field, $encrypt)) {
							$search = md5($value[3]);
						}
						
						if($operator == 'BETWEEN' or $operator == 'NOT BETWEEN') {
							foreach(explode(",", $value[3]) as $invalue) {
								array_push($this->value, $invalue);
							}
						} else {
							array_push($this->value, $search);
						}
						
						if(strpos($field, "DATE_ADD") !== false and strpos($field, "INTERVAL") !== false) {
							$this->sql .= " {$contructor} {$field} {$operator} ?";
						} else if(in_array($operator, $operators)) {
							$this->sql .= " {$contructor} {$this->table}.{$field} {$operator} ?";
						} else if($operator == 'SOUNDEX') {
							$this->sql .= " {$contructor} {$operator}({$this->table}.{$field}) = {$operator}(?)";
						} else if($operator == 'BETWEEN' or $operator == 'NOT BETWEEN') {
							$this->sql .= " {$contructor} {$this->table}.{$field} {$operator} ? AND ?";
						}
					}
				}			
			}
			
			return $this;
		}
		
		private function order($data) {
			if(count($data) > 0 and json_decode($data) == true) {
				$data = json_decode($data);
			}
			
			if(count($data) == 2) {
				$order = $data[0];
				$sort = strtoupper($data[1]);
				
				$this->sql .= " ORDER BY {$order} {$sort}";
			}
			
			return $this;
		}
		
		public function results() {
			return $this->result;
		}
		
		public function first() {
			return $this->results()[0];
		}
		
		public function count() {
			return $this->count;
		}
		
		public function json() {
			return $this->utf8ize($this->result);
		}
		
		public function error() {
			return $this->error;
		}
		
		public function status() {
			return  $this->utf8ize($this->status);
		}
		
		private function utf8ize($data) {
			if(is_array($data)) {
				foreach($data as $key => $value) {
					unset($data[$key]);
					$data[$this->utf8ize($key)] = $this->utf8ize($value);
				}
			} else if(is_object($data)) {
				$objVars = get_object_vars($data);
				foreach($objVars as $key => $value) {
					$data->$key = $this->utf8ize($value);
				}
			} else if(is_string ($data)) {
				return iconv('UTF-8', 'UTF-8//IGNORE', utf8_encode($data));
			}
			
			return $data;
		}
	}
?>