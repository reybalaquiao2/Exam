<?php
	$encrypt = array(
		"ParameterName"
	);
	
	$variables = (object) array(
		'buildsql' => (object) array(
			'fields' => (object) array(
				'TableName' => (object) array(
					'ParameterName'
				)
			),
			'references' => (object) array(
				'TableName' => (object) array(
					'fields' => (object) array('ParameterName'),
					'on' => 'ParameterName',
					'show' => (object) array('ParameterName', 'ParameterName')
				)
			),
			'masks' => (object) array(
				'TableName' => (object) array(
					'DateTimeParameter'
				)
			),
			'cast' => (object) array(
				'TableName' => (object) array(
					'DateTimeParameter'
				),
			),
			'replace' => (object) array(
				'TableName' => (object) array(
					array('ParameterName', 'Value', 'ReplaceValue'),
				)
			),
		)
	);
?>