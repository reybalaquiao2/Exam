<?php
	if (session_id() == "") {
		session_start();
	}
	ob_start();
	
	Class Functions {
		private static $instance = null;
		private $status;
		
		public static function getInstance() {
			if(!isset(self::$instance)) {
				self::$instance = new Functions();
			}
			return self::$instance;
		}
				
		private function jsonDecode($settings, $key) {
			if(count($settings[$key]) > 0 and json_decode($settings[$key]) == true) {
				$settings[$key] = json_decode($settings[$key]);
			}
			
			return $settings;
		}
		
		public function status() {
			return  $this->utf8ize($this->status);
		}
		
		private function utf8ize($data) {
			if(is_array($data)) {
				foreach($data as $key => $value) {
					unset($data[$key]);
					$data[$this->utf8ize($key)] = $this->utf8ize($value);
				}
			} else if(is_object($data)) {
				$objvars = get_object_vars($data);
				foreach($objvars as $key => $value) {
					$data->$key = $this->utf8ize($value);
				}
			} else if(is_string ($data)) {
				return iconv('UTF-8', 'UTF-8//IGNORE', utf8_encode($data));
			}
			
			return $data;
		}
	}
?>