<?php
	if (session_id() == "") {
		session_start();
	}
	
	ob_start();
	
	spl_autoload_register(function($class) {
		require_once "phpclasses/{$class}.php";
	});
	
	if(isset($_REQUEST['validate']) and $_REQUEST['validate']) {
		if($_REQUEST['action']) {
			switch($_REQUEST['action']) {
				case "get":
						echo json_encode(DB::getInstance()->get($_REQUEST)->json());
					break;
				case "post":
						echo json_encode(DB::getInstance()->post($_REQUEST)->status());
					break;
				case "update":
						echo json_encode(DB::getInstance()->update($_REQUEST)->status());
					break;
				case "delete":
						echo json_encode(DB::getInstance()->delete($_REQUEST)->status());
					break;
			}
		}
	}
?>