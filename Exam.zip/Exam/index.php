<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Exam</title>
		
		<link rel="stylesheet" type="text/css" href="phpcss/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="phpcss/bootstrap-grid.css">
		<link rel="stylesheet" type="text/css" href="phpcss/bootstrap-reboot.css">
		<link rel="stylesheet" type="text/css" href="phpcss/bootstrap-glyphicon.css">
		<link rel="stylesheet" type="text/css" href="phpcss/exam.css">
		<link rel="stylesheet" type="text/css" href="phpcss/datatables.css">
		<link rel="stylesheet" type="text/css" href="phpcss/flatpickr.min.css">
		
		<script type="text/javascript" src="phpjs/phpplugins/jquery3.3.1.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/angularjs1.7.8.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/angularjs_resource.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/bootstrap.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/datatables.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/flatpickr.js"></script>
		<script type="text/javascript" src="phpjs/phpscript/srt_index.js"></script>
		<script type="text/javascript" src="phpjs/phpscript/srt_function.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/alasql.js"></script>
		<script type="text/javascript" src="phpjs/phpplugins/xlsx.core.js"></script>
	</head>
	<body>
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
			<a class="navbar-brand" href="/Exam">CRUD Program</a>
		</nav>
		<div class="container-fluid" ng-app="IndexApp" ng-controller="IndexCtrl">
			<div class="row">
				<div class="col-lg-1"></div>
				<div class="col-lg-10">
					<div class="row">
						<div class="col-lg-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">
										<i class="fa fa-users fa-lg fa-fw"></i> EMPLOYEE'S RECORD
									</div>
								</div>
								<div class="card-body body-content">
									<div class="row">
										<div class="col-lg">
											<form>
												<div class="row">
													<div class="col-lg-12">
														<div class="form-group">
															<div class="btn-group btn-action">
																<button type="button" class="btn btn-primary btn-sm" title="Add" ng-click="openModal('EmployeeModal', 'Add')">
																	<i class="fa fa-file fa-lg fa-fw"></i>
																</button>
																<button type="button" class="btn btn-primary btn-sm" title="Edit" ng-click="openModal('EmployeeModal', 'Edit')" ng-disabled="!settings.highlighted">
																	<i class="fa fa-edit fa-lg fa-fw"></i>
																</button>
																<button type="button" class="btn btn-primary btn-sm" title="View" ng-click="openModal('EmployeeModal', 'View')" ng-disabled="!settings.highlighted">
																	<i class="fa fa-eye fa-lg fa-fw"></i>
																</button>
																<button type="button" class="btn btn-primary btn-sm" title="Delete" ng-click="openModal('ConfirmModal', 'Delete')" ng-disabled="!settings.highlighted">
																	<i class="fa fa-trash-o fa-lg fa-fw"></i>
																</button>
																<button type="button" class="btn btn-primary btn-sm" title="Download" ng-click="download()">
																	<i class="fa fa-download fa-lg fa-fw"></i>
																</button>
																<div class="input-group">
																	<div class="input-group-prepend">
																		<span class="input-group-text prepend-search">
																			<i class="fa fa-search fa-lg fa-fw"></i>
																		</span>
																	</div>
																	<input id="employeeSearchInput" type="text" class="form-control form-control-md" ng-model="settings.search" placeholder="Search..." uppercase-only/>
																</div>
															</div>
														</div>
													</div>
												</div>
											</form>
											<div class="table-responsive table-responsive-sm">
												<table id="employeeTable" class="table table-sm table-bordered table-striped table-hover table-responsive">
													<thead class="thead-dark">
														<tr>
															<th>Code</th>
															<th>Employee No.</th>
															<th>First Name</th>
															<th>Last Name</th>
															<th>Department</th>
														</tr>
													</thead>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg">
							<div class="row">
								<div class="col-lg footer-copyright">
									<center>
										<span>&copy; Copyright 2021, Rey M. Balaquiao. All rights reserved.</span>
									</center>
								</div>
							</div>
						</div>
					</div>	
				</div>
			</div>
			<div id="Spinner" class="modal fade" data-backdrop="static">
				<div class="modal-dialog modal-dialog-centered text-center">
					<div class="modal-content">
						<span class="fa fa-spinner fa-spin fa-3x"></span>
						<span class="spinner-title"></span>
					</div>
				</div>
			</div>
			<div id="EmployeeModal" class="modal fade" data-backdrop="static">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title">EMPLOYEE DETAILS</h4>
						</div>
						<div class="modal-body">
							<form>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label>
												Employee No.
												<span class="required-span">*</span>
											</label>
											<input type="text" class="form-control form-control-sm" value="{{ form.EmployeeNo }}" ng-model="form.EmployeeNo" ng-disabled="!settings.enabled" placeholder="8 DIGIT NUMBER" numbers-only/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg">
										<div class="form-group">
											<label>
												First Name
												<span class="required-span">*</span>
											</label>
											<input type="text" class="form-control form-control-sm form-upper" value="{{ form.FirstName }}" ng-model="form.FirstName" ng-disabled="!settings.enabled" uppercase-only/>
										</div>
									</div>
									<div class="col-lg">
										<div class="form-group">
											<label>
												Last Name
												<span class="required-span">*</span>
											</label>
											<input type="text" class="form-control form-control-sm form-upper" value="{{ form.LastName }}" ng-model="form.LastName" ng-disabled="!settings.enabled" uppercase-only/>
										</div>						
									</div>
								</div>
								<div class="row">
									<div class="col-lg">
										<div class="form-group">
											<label>
												Department
												<span class="required-span">*</span>
											</label>
											<input type="text" class="form-control form-control-sm form-upper" value="{{ form.Department }}" ng-model="form.Department" ng-disabled="!settings.enabled" uppercase-only/>
										</div>						
									</div>
								</div>
							</form>
						</div>
						<div class="modal-footer">
							<button id="AddButton" type="button" class="btn btn-primary" ng-click="add()">ADD</button>
							<button id="EditButton" type="button" class="btn btn-primary" ng-click="edit()">UPDATE</button>
							<button type="button" class="btn btn-danger" ng-click="closeModal('EmployeeModal')">CLOSE</button>
						</div>
					</div>
				</div>
			</div>
			<div id="AlertModal" class="modal fade" data-backdrop="static">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title">{{ settings.modal.title }}</h4>
						</div>
						<div class="modal-body">
							<i class="fa fa-{{ settings.modal.type }} fa-lg {{ settings.modal.type }}"></i> {{ settings.modal.message }}
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-danger" ng-click="closeModal('AlertModal')">CLOSE</button>
						</div>
					</div>
				</div>
			</div>
			<div id="ConfirmModal" class="modal fade" data-backdrop="static">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title">CONFIRM</h4>
						</div>
						<div class="modal-body">
							<i class="fa fa-questionmark fa-lg {{ settings.modal.type }}"></i>Do you want to continue deleting this record?
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-success" ng-click="Delete()">YES</button>
							<button type="button" class="btn btn-danger" ng-click="closeModal('ConfirmModal')">NO</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
